# Data Directory

This repository intentionally does **not** include the otoscopic image files.

Expected local layout:

```text
data/raw/Otoscopic_Data/
├── Acute Otitis Media/
├── Cerumen Impaction/
├── Chronic Otitis Media/
├── Myringosclerosis/
└── Normal/
```

`dataset_inventory.csv` contains archive-level metadata only. It is included to
document the initial inventory and duplicate warning without redistributing the
medical images.

Before publishing the dataset itself, verify redistribution rights and any
clinical/privacy obligations.
