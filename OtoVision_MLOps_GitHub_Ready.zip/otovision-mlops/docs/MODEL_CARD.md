# Model Card — OtoVision-MLOps

## Model details

- Task: five-class otoscopic image classification
- Default architecture: EfficientNet-B0 transfer learning
- Inputs: RGB otoscopic image
- Outputs: class probabilities + uncertainty-derived review routing
- Intended status: research / portfolio demonstration

## Intended use

The system is intended to demonstrate applied computer vision, ML engineering,
uncertainty-aware workflow design, explainability, and deployment practices.

## Out-of-scope use

- autonomous diagnosis
- emergency decision making
- treatment recommendation
- use as a regulated medical device without appropriate validation and approval

## Evaluation

Populate this section only from `artifacts/evaluation/metrics.json` after a real
training/evaluation run. Report class-wise performance, calibration, selective
coverage, and confidence intervals where appropriate.

## Limitations

Expected limitations include dataset shift, acquisition-device variation,
illumination differences, image quality, label ambiguity, insufficient external
validation, and absence of patient-level grouping when patient identifiers are
not available.

## Human oversight

Low-confidence or high-entropy predictions are routed to `human_review`.
Thresholds are configurable and must be selected using validation data for any
real deployment study.
