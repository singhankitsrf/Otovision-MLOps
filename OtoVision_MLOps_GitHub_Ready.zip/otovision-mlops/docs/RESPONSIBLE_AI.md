# Responsible AI Notes

This repository deliberately separates a technically deployable API from a claim
of clinical readiness.

## Safety boundaries

- The service returns a review decision in addition to a predicted class.
- Uncertain predictions are not silently converted into confident diagnoses.
- No therapeutic advice is generated.
- Performance claims must come from held-out evaluation.
- External validation is required before any clinical-use claim.
- Dataset provenance and redistribution rights must be documented independently.

## Bias and generalization

A model can learn camera signatures, illumination, borders, source-specific
compression, or other shortcuts. The preprocessing and audit steps reduce some
risks but do not prove demographic, device, or site generalization.

## Privacy

Do not commit identifiable patient data, hidden metadata, or private clinical
records. Use only data that is legally and ethically permitted for the intended
purpose.
