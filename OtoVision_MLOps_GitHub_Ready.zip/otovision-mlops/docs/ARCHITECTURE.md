# Architecture

## Offline ML path

```mermaid
flowchart TD
    A[Raw class folders] --> B[Image validation]
    B --> C[SHA-256 duplicate audit]
    C --> D[Leakage-aware manifest]
    D --> E[Train/Val/Test loaders]
    E --> F[EfficientNet-B0]
    F --> G[Best checkpoint by macro F1]
    G --> H[Test evaluation]
    H --> I[Calibration diagnostics]
    H --> J[Selective coverage]
    G --> K[Grad-CAM]
```

## Online inference path

```mermaid
sequenceDiagram
    participant Client
    participant API as FastAPI
    participant Prep as Preprocessing
    participant Model as PyTorch model
    participant Triage as Risk-aware triage

    Client->>API: POST /predict image
    API->>Prep: validate + crop dark border + normalize
    Prep->>Model: tensor
    Model-->>API: class probabilities
    API->>Triage: confidence + entropy
    Triage-->>API: assisted prediction or human review
    API-->>Client: JSON response
```

## Design principles

1. **Data integrity before modeling.**
2. **No hard-coded performance claims.**
3. **Human review is an explicit output state.**
4. **Inference code reuses training-time transforms.**
5. **Deployment artifacts are version-controlled; model weights and data are not.**
