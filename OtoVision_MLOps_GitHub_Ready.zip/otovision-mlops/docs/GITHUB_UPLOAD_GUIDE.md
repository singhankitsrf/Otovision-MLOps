# GitHub Upload Guide

## A. Create the repository on GitHub

1. Sign in to GitHub.
2. Select **New repository**.
3. Repository name: `otovision-mlops`
4. Suggested description:

   `Production-grade Healthcare AI for otoscopic image classification: leakage-aware data QA, PyTorch, uncertainty-aware triage, Grad-CAM, FastAPI, Docker, Kubernetes and CI.`

5. Choose **Public** if you want recruiters to inspect the code.
6. Do not initialize with another README, `.gitignore`, or license because those files already exist here.
7. Create the repository.

## B. Verify that medical images are excluded

From the project folder:

```bash
git status
```

Make sure `data/raw/`, `.rar`, `.zip`, model checkpoints and `.env` files are not staged.

## C. Initialize Git locally

```bash
cd otovision-mlops
git init
git branch -M main
git add .
git status
git commit -m "feat: launch OtoVision-MLOps healthcare AI platform"
```

## D. Connect to GitHub

Replace `YOUR_USERNAME`:

```bash
git remote add origin https://github.com/YOUR_USERNAME/otovision-mlops.git
git push -u origin main
```

## E. Add repository topics

Recommended topics:

```text
healthcare-ai
medical-imaging
computer-vision
pytorch
deep-learning
mlops
fastapi
docker
kubernetes
explainable-ai
gradcam
responsible-ai
```

## F. Pin the repository

Open your GitHub profile → **Customize your pins** → select `otovision-mlops`.

## G. Make the first impression stronger

After you run real experiments:

1. add real evaluation figures from `artifacts/evaluation/`;
2. add one or two de-identified, redistribution-safe Grad-CAM examples;
3. add the measured API latency on your hardware;
4. update `docs/MODEL_CARD.md` with actual results;
5. never invent metrics;
6. add a short demo video/GIF only if the underlying image license permits it.

## H. Recommended Git workflow for improvements

```bash
git checkout -b feature/temperature-scaling
# make changes
git add .
git commit -m "feat: add validation-based temperature scaling"
git push -u origin feature/temperature-scaling
```

Open a Pull Request on GitHub. This visibly demonstrates professional software-engineering practice.

## I. Recruiter-facing repository description

Use this short description:

`Healthcare AI platform for 5-class otoscopic image analysis with leakage-aware data QA, risk-aware inference, Grad-CAM, FastAPI, Docker, Kubernetes and CI.`

## J. Suggested GitHub profile link text

`Featured project: OtoVision-MLOps — production-oriented Healthcare AI from data QA to Kubernetes deployment.`
