# Dataset Audit

## Source archive inventory

The supplied archive was inspected at the file-header level.

- Total JPEG files: **3000**
- Classes: **5**
- Archive count per class: **600 each**
- Unique archive CRC values: **2922**
- Repeated-content CRC groups: **78**
- Files participating in repeated groups: **156**
- Duplicate surplus relative to one canonical file per CRC group: **78**
- Cross-class duplicate CRC groups: **0**

### Canonical count after archive-level duplicate warning

| Class | Archive files | Duplicate surplus flagged | Canonical estimate |
|---|---:|---:|---:|
| Acute Otitis Media | 600 | 78 | 522 |
| Cerumen Impaction | 600 | 0 | 600 |
| Chronic Otitis Media | 600 | 0 | 600 |
| Myringosclerosis | 600 | 0 | 600 |
| Normal | 600 | 0 | 600 |

## Important interpretation

CRC32 is useful for screening archive entries but is not treated as the final duplicate identity mechanism. The executable data-preparation pipeline computes **SHA-256 on extracted image bytes** and uses that stronger digest to exclude exact duplicates before splitting.

The audit also guards against a more serious failure mode: the same exact image appearing under different class labels. If that condition is detected, dataset preparation stops and requires manual resolution.

## Why this matters

Randomly splitting repeated images can inflate test metrics because the model may encounter the exact same pixels during training and testing. A portfolio-quality medical-imaging project should explicitly defend against this leakage.

## Additional QA recommended before publishing model results

- patient/exam-level grouping if identifiers exist
- perceptual near-duplicate review
- acquisition-device/source stratification
- label adjudication for ambiguous cases
- external validation
- subgroup analysis where ethically and legally available
