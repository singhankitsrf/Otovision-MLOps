# Security

Do not open a public issue containing patient-identifiable data, private dataset
paths, credentials, API keys, cloud secrets, or proprietary model artifacts.

If this repository is adapted for a real clinical environment, add formal
threat modeling, authentication/authorization, audit logging, dependency
scanning, secret management, encryption, and organization-specific controls.
