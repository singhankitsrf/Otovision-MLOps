from __future__ import annotations

import io
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, File, HTTPException, UploadFile
from PIL import Image, UnidentifiedImageError

from .inference import load_checkpoint, predict_image

STATE = {
    "model": None,
    "class_names": None,
    "image_size": None,
    "device": None,
}


@asynccontextmanager
async def lifespan(app: FastAPI):
    model_path = os.getenv("MODEL_PATH", "artifacts/models/best.pt")
    if os.path.exists(model_path):
        model, class_names, image_size, device = load_checkpoint(model_path)
        STATE.update(
            model=model,
            class_names=class_names,
            image_size=image_size,
            device=device,
        )
    yield


app = FastAPI(
    title="OtoVision-MLOps API",
    version="0.1.0",
    description="Research-only otoscopic image classification with risk-aware review routing.",
    lifespan=lifespan,
)


@app.get("/health")
def health():
    return {
        "status": "ok",
        "model_loaded": STATE["model"] is not None,
    }


@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    if STATE["model"] is None:
        raise HTTPException(status_code=503, detail="Model checkpoint is not loaded.")

    if file.content_type not in {"image/jpeg", "image/png", "image/webp"}:
        raise HTTPException(status_code=415, detail="Unsupported image media type.")

    raw = await file.read()
    try:
        image = Image.open(io.BytesIO(raw)).convert("RGB")
    except UnidentifiedImageError as exc:
        raise HTTPException(status_code=400, detail="Invalid image.") from exc

    min_conf = float(os.getenv("MIN_CONFIDENCE", "0.75"))
    max_entropy = float(os.getenv("MAX_NORMALIZED_ENTROPY", "0.65"))

    return predict_image(
        STATE["model"],
        image,
        STATE["class_names"],
        STATE["image_size"],
        STATE["device"],
        min_confidence=min_conf,
        max_normalized_entropy=max_entropy,
    )
