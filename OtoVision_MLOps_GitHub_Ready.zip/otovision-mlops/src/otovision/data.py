from __future__ import annotations

from pathlib import Path

import pandas as pd
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms

from .preprocessing import crop_dark_border


class ManifestImageDataset(Dataset):
    def __init__(self, frame: pd.DataFrame, data_root: str | Path, transform=None):
        self.frame = frame.reset_index(drop=True)
        self.data_root = Path(data_root)
        self.transform = transform
        self.class_names = sorted(self.frame["class_name"].unique().tolist())
        self.class_to_idx = {name: idx for idx, name in enumerate(self.class_names)}

    def __len__(self):
        return len(self.frame)

    def __getitem__(self, index):
        row = self.frame.iloc[index]
        path = self.data_root / row["relative_path"]
        with Image.open(path) as image:
            image = crop_dark_border(image.convert("RGB"))
            if self.transform:
                image = self.transform(image)
        label = self.class_to_idx[row["class_name"]]
        return image, torch.tensor(label, dtype=torch.long), str(path)


def build_transforms(image_size: int):
    train_tf = transforms.Compose(
        [
            transforms.RandomResizedCrop(image_size, scale=(0.85, 1.0), ratio=(0.9, 1.1)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomRotation(degrees=10),
            transforms.ColorJitter(brightness=0.15, contrast=0.15, saturation=0.10, hue=0.02),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ]
    )
    eval_tf = transforms.Compose(
        [
            transforms.Resize(int(image_size * 1.14)),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ]
    )
    return train_tf, eval_tf


def load_manifest(manifest_path: str | Path) -> pd.DataFrame:
    frame = pd.read_csv(manifest_path)
    required = {"relative_path", "class_name", "split", "is_exact_duplicate"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Manifest missing columns: {sorted(missing)}")
    return frame[~frame["is_exact_duplicate"].astype(bool)].copy()


def build_loaders(
    manifest_path: str | Path,
    data_root: str | Path,
    image_size: int,
    batch_size: int,
    num_workers: int,
):
    frame = load_manifest(manifest_path)
    train_tf, eval_tf = build_transforms(image_size)

    datasets = {}
    loaders = {}
    for split in ("train", "val", "test"):
        subset = frame[frame["split"] == split].copy()
        tf = train_tf if split == "train" else eval_tf
        ds = ManifestImageDataset(subset, data_root, transform=tf)
        datasets[split] = ds
        loaders[split] = DataLoader(
            ds,
            batch_size=batch_size,
            shuffle=(split == "train"),
            num_workers=num_workers,
            pin_memory=torch.cuda.is_available(),
            persistent_workers=(num_workers > 0),
        )

    if datasets["train"].class_names != datasets["val"].class_names or        datasets["train"].class_names != datasets["test"].class_names:
        raise ValueError("All splits must contain the same classes.")

    return loaders, datasets["train"].class_names
