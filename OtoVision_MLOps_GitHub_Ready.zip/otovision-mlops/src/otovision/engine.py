from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from sklearn.metrics import f1_score


@dataclass
class EpochResult:
    loss: float
    accuracy: float
    macro_f1: float


def run_epoch(model, loader, criterion, device, optimizer=None, scaler=None):
    training = optimizer is not None
    model.train(training)

    losses = []
    y_true, y_pred = [], []

    for images, labels, _ in loader:
        images = images.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        if training:
            optimizer.zero_grad(set_to_none=True)

        use_amp = scaler is not None and device.type == "cuda"
        with torch.autocast(device_type=device.type, enabled=use_amp):
            logits = model(images)
            loss = criterion(logits, labels)

        if training:
            if use_amp:
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
            else:
                loss.backward()
                optimizer.step()

        losses.append(loss.detach().item())
        preds = logits.argmax(dim=1)
        y_true.extend(labels.detach().cpu().tolist())
        y_pred.extend(preds.detach().cpu().tolist())

    return EpochResult(
        loss=float(np.mean(losses)) if losses else float("nan"),
        accuracy=float(np.mean(np.asarray(y_true) == np.asarray(y_pred))),
        macro_f1=float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
    )


@torch.inference_mode()
def predict_loader(model, loader, device):
    model.eval()
    y_true, probabilities, paths = [], [], []
    for images, labels, batch_paths in loader:
        images = images.to(device, non_blocking=True)
        logits = model(images)
        probs = torch.softmax(logits, dim=1)
        y_true.extend(labels.tolist())
        probabilities.extend(probs.cpu().numpy())
        paths.extend(batch_paths)
    return np.asarray(y_true), np.asarray(probabilities), paths
