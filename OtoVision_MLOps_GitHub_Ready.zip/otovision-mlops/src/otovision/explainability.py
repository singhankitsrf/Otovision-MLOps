from __future__ import annotations

import numpy as np
import torch
from PIL import Image
from torchvision import transforms


class GradCAM:
    def __init__(self, model, target_layer):
        self.model = model
        self.activations = None
        self.gradients = None
        self._forward = target_layer.register_forward_hook(self._save_activations)
        self._backward = target_layer.register_full_backward_hook(self._save_gradients)

    def _save_activations(self, module, inputs, output):
        self.activations = output.detach()

    def _save_gradients(self, module, grad_input, grad_output):
        self.gradients = grad_output[0].detach()

    def close(self):
        self._forward.remove()
        self._backward.remove()

    def __call__(self, x, class_index=None):
        self.model.zero_grad(set_to_none=True)
        logits = self.model(x)
        if class_index is None:
            class_index = int(logits.argmax(dim=1).item())
        logits[:, class_index].sum().backward()

        weights = self.gradients.mean(dim=(2, 3), keepdim=True)
        cam = (weights * self.activations).sum(dim=1)
        cam = torch.relu(cam)[0]
        cam -= cam.min()
        cam /= cam.max().clamp_min(1e-8)
        return cam.cpu().numpy(), class_index


def overlay_cam(image: Image.Image, cam: np.ndarray, alpha: float = 0.40) -> Image.Image:
    base = image.convert("RGB")
    cam_img = Image.fromarray(np.uint8(cam * 255)).resize(base.size)
    heat = transforms.functional.to_tensor(cam_img)
    # A simple red/yellow-like map without external visualization dependencies.
    h = heat[0]
    colored = torch.stack([h, torch.sqrt(h), torch.zeros_like(h)], dim=0)
    base_t = transforms.functional.to_tensor(base)
    out = (1 - alpha) * base_t + alpha * colored
    out = out.clamp(0, 1)
    return transforms.functional.to_pil_image(out)
