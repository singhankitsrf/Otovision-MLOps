from __future__ import annotations

import argparse
from pathlib import Path

import torch

from otovision.inference import load_checkpoint


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", default="artifacts/models/best.pt")
    parser.add_argument("--output", default="artifacts/models/otovision.ts")
    args = parser.parse_args()

    model, _, image_size, device = load_checkpoint(args.checkpoint)
    example = torch.randn(1, 3, image_size, image_size, device=device)
    traced = torch.jit.trace(model, example)

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    traced.save(str(out))
    print(f"TorchScript model: {out}")


if __name__ == "__main__":
    main()
