from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import pandas as pd
from PIL import Image, UnidentifiedImageError
from sklearn.model_selection import train_test_split


SUPPORTED = {".jpg", ".jpeg", ".png", ".webp"}


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def scan(data_root: Path) -> pd.DataFrame:
    rows = []
    for path in sorted(data_root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in SUPPORTED:
            continue
        try:
            with Image.open(path) as image:
                image.verify()
            with Image.open(path) as image:
                width, height = image.size
                mode = image.mode
            rows.append(
                {
                    "relative_path": path.relative_to(data_root).as_posix(),
                    "class_name": path.parent.name,
                    "sha256": sha256_file(path),
                    "width": width,
                    "height": height,
                    "mode": mode,
                    "readable": True,
                }
            )
        except (UnidentifiedImageError, OSError):
            rows.append(
                {
                    "relative_path": path.relative_to(data_root).as_posix(),
                    "class_name": path.parent.name,
                    "sha256": "",
                    "width": None,
                    "height": None,
                    "mode": "",
                    "readable": False,
                }
            )
    return pd.DataFrame(rows)


def assign_splits(frame: pd.DataFrame, seed: int) -> pd.DataFrame:
    frame = frame.copy()
    frame["is_exact_duplicate"] = False
    frame["canonical_relative_path"] = ""

    readable = frame[frame["readable"]].copy()
    for _, group in readable.groupby("sha256"):
        canonical = sorted(group["relative_path"].tolist())[0]
        idx = group.index
        frame.loc[idx, "canonical_relative_path"] = canonical
        duplicates = group[group["relative_path"] != canonical].index
        frame.loc[duplicates, "is_exact_duplicate"] = True

    canonical = frame[(frame["readable"]) & (~frame["is_exact_duplicate"])].copy()

    # Guard against identical content having conflicting labels.
    conflicts = (
        readable.groupby("sha256")["class_name"].nunique().reset_index(name="n_classes")
    )
    conflicts = conflicts[conflicts["n_classes"] > 1]
    if not conflicts.empty:
        raise RuntimeError(
            "Identical image content appears under different labels. Resolve before training."
        )

    train_idx, temp_idx = train_test_split(
        canonical.index,
        test_size=0.30,
        random_state=seed,
        stratify=canonical["class_name"],
    )
    val_idx, test_idx = train_test_split(
        temp_idx,
        test_size=0.50,
        random_state=seed,
        stratify=canonical.loc[temp_idx, "class_name"],
    )

    frame["split"] = "excluded"
    frame.loc[train_idx, "split"] = "train"
    frame.loc[val_idx, "split"] = "val"
    frame.loc[test_idx, "split"] = "test"
    frame.loc[~frame["readable"], "split"] = "invalid"
    return frame


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", required=True)
    parser.add_argument(
        "--manifest",
        default="artifacts/manifests/dataset_manifest.csv",
    )
    parser.add_argument("--split-seed", type=int, default=42)
    args = parser.parse_args()

    data_root = Path(args.data_root)
    out = Path(args.manifest)
    out.parent.mkdir(parents=True, exist_ok=True)

    frame = scan(data_root)
    if frame.empty:
        raise RuntimeError(f"No supported images found under {data_root}")

    frame = assign_splits(frame, args.split_seed)
    frame.to_csv(out, index=False)

    print(f"Manifest: {out}")
    print(f"Total files: {len(frame)}")
    print(f"Readable: {int(frame['readable'].sum())}")
    print(f"Exact duplicate surplus: {int(frame['is_exact_duplicate'].sum())}")
    print("\nSplit counts:")
    print(frame["split"].value_counts())
    print("\nCanonical class counts:")
    canonical = frame[(frame["readable"]) & (~frame["is_exact_duplicate"])]
    print(canonical["class_name"].value_counts().sort_index())


if __name__ == "__main__":
    main()
