from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch import nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.tensorboard import SummaryWriter

from otovision.data import build_loaders
from otovision.engine import run_epoch
from otovision.model import build_model
from otovision.utils import ensure_dir, load_yaml, seed_everything


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/train.yaml")
    args = parser.parse_args()

    cfg = load_yaml(args.config)
    seed_everything(int(cfg["seed"]))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dcfg = cfg["data"]
    tcfg = cfg["training"]
    mcfg = cfg["model"]
    ocfg = cfg["output"]

    loaders, class_names = build_loaders(
        manifest_path=dcfg["manifest"],
        data_root=dcfg["root"],
        image_size=int(dcfg["image_size"]),
        batch_size=int(dcfg["batch_size"]),
        num_workers=int(dcfg["num_workers"]),
    )

    model = build_model(
        num_classes=len(class_names),
        pretrained=bool(mcfg["pretrained"]),
        dropout=float(mcfg["dropout"]),
    ).to(device)

    criterion = nn.CrossEntropyLoss(label_smoothing=float(tcfg["label_smoothing"]))
    optimizer = AdamW(
        model.parameters(),
        lr=float(tcfg["learning_rate"]),
        weight_decay=float(tcfg["weight_decay"]),
    )
    scheduler = CosineAnnealingLR(optimizer, T_max=int(tcfg["epochs"]))
    scaler = torch.cuda.amp.GradScaler(
        enabled=(bool(tcfg["amp"]) and device.type == "cuda")
    )

    model_dir = ensure_dir(ocfg["model_dir"])
    run_dir = ensure_dir(ocfg["run_dir"])
    writer = SummaryWriter(log_dir=str(run_dir / "efficientnet_b0"))

    best_f1 = -1.0
    bad_epochs = 0

    for epoch in range(1, int(tcfg["epochs"]) + 1):
        train_result = run_epoch(
            model, loaders["train"], criterion, device, optimizer, scaler
        )
        val_result = run_epoch(model, loaders["val"], criterion, device)
        scheduler.step()

        writer.add_scalar("loss/train", train_result.loss, epoch)
        writer.add_scalar("loss/val", val_result.loss, epoch)
        writer.add_scalar("macro_f1/train", train_result.macro_f1, epoch)
        writer.add_scalar("macro_f1/val", val_result.macro_f1, epoch)
        writer.add_scalar("accuracy/train", train_result.accuracy, epoch)
        writer.add_scalar("accuracy/val", val_result.accuracy, epoch)
        writer.add_scalar("lr", optimizer.param_groups[0]["lr"], epoch)

        print(
            f"Epoch {epoch:03d} | "
            f"train loss={train_result.loss:.4f} f1={train_result.macro_f1:.4f} | "
            f"val loss={val_result.loss:.4f} f1={val_result.macro_f1:.4f}"
        )

        if val_result.macro_f1 > best_f1:
            best_f1 = val_result.macro_f1
            bad_epochs = 0
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "class_names": class_names,
                    "image_size": int(dcfg["image_size"]),
                    "dropout": float(mcfg["dropout"]),
                    "val_macro_f1": float(best_f1),
                    "config": cfg,
                },
                model_dir / "best.pt",
            )
        else:
            bad_epochs += 1
            if bad_epochs >= int(tcfg["patience"]):
                print("Early stopping.")
                break

    writer.close()
    print(f"Best validation macro F1: {best_f1:.4f}")
    print(f"Checkpoint: {model_dir / 'best.pt'}")


if __name__ == "__main__":
    main()
