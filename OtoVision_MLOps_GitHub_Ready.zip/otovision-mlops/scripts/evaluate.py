from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import classification_report, confusion_matrix

from otovision.data import build_loaders
from otovision.engine import predict_loader
from otovision.inference import load_checkpoint
from otovision.metrics import (
    expected_calibration_error,
    per_class_specificity,
    summary_metrics,
)
from otovision.triage import normalized_entropy
from otovision.utils import ensure_dir, load_yaml


def plot_confusion(y_true, y_pred, class_names, path):
    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(class_names))))
    fig, ax = plt.subplots(figsize=(8, 7))
    im = ax.imshow(cm)
    ax.set(
        xticks=np.arange(len(class_names)),
        yticks=np.arange(len(class_names)),
        xticklabels=class_names,
        yticklabels=class_names,
        xlabel="Predicted",
        ylabel="True",
        title="Confusion Matrix",
    )
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center")
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def plot_reliability(y_true, probs, path, n_bins=10):
    confidence = probs.max(axis=1)
    pred = probs.argmax(axis=1)
    correct = (pred == y_true).astype(float)
    edges = np.linspace(0, 1, n_bins + 1)
    xs, ys = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (confidence > lo) & (confidence <= hi)
        if mask.any():
            xs.append(confidence[mask].mean())
            ys.append(correct[mask].mean())
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.plot([0, 1], [0, 1], linestyle="--", label="Perfect calibration")
    ax.plot(xs, ys, marker="o", label="Model")
    ax.set(xlabel="Mean confidence", ylabel="Empirical accuracy", title="Reliability Diagram")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def selective_coverage(y_true, probs):
    pred = probs.argmax(axis=1)
    confidence = probs.max(axis=1)
    rows = []
    for threshold in np.arange(0.50, 0.96, 0.05):
        keep = confidence >= threshold
        if not keep.any():
            continue
        rows.append(
            {
                "min_confidence": round(float(threshold), 2),
                "coverage": float(keep.mean()),
                "accuracy_on_covered": float((pred[keep] == y_true[keep]).mean()),
                "review_rate": float(1.0 - keep.mean()),
            }
        )
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/train.yaml")
    parser.add_argument("--checkpoint", default="artifacts/models/best.pt")
    args = parser.parse_args()

    cfg = load_yaml(args.config)
    dcfg = cfg["data"]
    out_dir = ensure_dir(cfg["output"]["evaluation_dir"])

    loaders, manifest_classes = build_loaders(
        dcfg["manifest"],
        dcfg["root"],
        int(dcfg["image_size"]),
        int(dcfg["batch_size"]),
        int(dcfg["num_workers"]),
    )

    model, class_names, _, device = load_checkpoint(args.checkpoint)
    if class_names != manifest_classes:
        raise RuntimeError("Checkpoint class order differs from manifest class order.")

    y_true, probs, paths = predict_loader(model, loaders["test"], device)
    y_pred = probs.argmax(axis=1)

    metrics = summary_metrics(y_true, probs)
    specificity = per_class_specificity(y_true, y_pred, len(class_names))
    metrics["per_class_specificity"] = {
        name: specificity[i] for i, name in enumerate(class_names)
    }

    report = classification_report(
        y_true,
        y_pred,
        labels=list(range(len(class_names))),
        target_names=class_names,
        output_dict=True,
        zero_division=0,
    )

    with open(out_dir / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    pd.DataFrame(report).T.to_csv(out_dir / "classification_report.csv")

    pred_frame = pd.DataFrame({
        "path": paths,
        "true_index": y_true,
        "pred_index": y_pred,
        "confidence": probs.max(axis=1),
        "normalized_entropy": [normalized_entropy(p) for p in probs],
    })
    for i, name in enumerate(class_names):
        pred_frame[f"p_{name}"] = probs[:, i]
    pred_frame.to_csv(out_dir / "predictions.csv", index=False)

    selective_coverage(y_true, probs).to_csv(
        out_dir / "selective_coverage.csv", index=False
    )

    plot_confusion(y_true, y_pred, class_names, out_dir / "confusion_matrix.png")
    plot_reliability(y_true, probs, out_dir / "reliability_diagram.png")

    print(json.dumps(metrics, indent=2))
    print(f"Evaluation artifacts: {out_dir}")


if __name__ == "__main__":
    main()
