# Kubernetes Deployment

1. Build and push the Docker image to your registry.
2. Replace `YOUR_REGISTRY/otovision-mlops:latest` in `deployment.yaml`.
3. Provision storage containing `best.pt` at `/models/best.pt`.
4. Apply:

```bash
kubectl apply -f deploy/k8s/
```

The HPA assumes a working Kubernetes Metrics Server.
For cloud deployment, adapt storage and ingress to the selected provider.
